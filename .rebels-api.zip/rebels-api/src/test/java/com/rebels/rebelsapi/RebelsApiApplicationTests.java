package com.rebels.rebelsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RebelsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
